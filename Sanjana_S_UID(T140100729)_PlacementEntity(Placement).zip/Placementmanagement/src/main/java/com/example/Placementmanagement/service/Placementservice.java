package com.example.Placementmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Placementmanagement.entity.Placement;
import com.example.Placementmanagement.restrepo.Placementrepo;

@Service
public class Placementservice {
	
	@Autowired
	private Placementrepo pr;
	
	public Placement registerplacement(Placement p) {
		return pr.save(p);
	}
	
	public List<Placement> getplacement(){
		return(List<Placement>)pr.findAll();
	}
	
	public void deleteplacement(Integer id) {
		pr.deleteById(id);
	}
	
	public Placement updateplacement(Integer id, Placement p) {

	    Placement po = pr.findById(id).orElse(null);

	    if (po != null) {
	        po.setName(p.getName());
	        po.setQualification(p.getQualification());
	        po.setYear(p.getYear());

	        return pr.save(po);
	    }

	    return null;
	}

}
