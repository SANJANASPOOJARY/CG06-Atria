package com.example.Placementmanagement.restrepo;

import org.springframework.data.repository.CrudRepository;

import com.example.Placementmanagement.entity.Placement;

public interface Placementrepo extends CrudRepository<Placement,Integer> {

}
