package com.example.Placementmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Placementmanagement.entity.Placement;
import com.example.Placementmanagement.service.Placementservice;

@RestController
public class Placementcontroller {
	
	@Autowired
	private Placementservice ps;
	
	@PostMapping("/saveplacement")
	public Placement registerplacement(@RequestBody Placement p) {
		return ps.registerplacement(p);
	}
	
	@GetMapping("/getplacement")
	public List<Placement> getplacement(){
		return ps.getplacement();
	}
	
	@DeleteMapping("/deleteplacement/{id}")
	public void deleteplacement(@PathVariable ("id")Integer id) {
		ps.deleteplacement(id);
	}
	
	@PutMapping("/updateplacement/{id}")
	public Placement updateplacement(@PathVariable Integer id,
	                                 @RequestBody Placement p) {

	    return ps.updateplacement(id, p);
	}
}
